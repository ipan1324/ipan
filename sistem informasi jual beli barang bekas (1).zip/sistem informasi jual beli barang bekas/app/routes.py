from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from .models import Barang, User, Transaksi
from . import db
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask import session, flash, redirect, url_for
main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('halaman_login.html')  

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash("Hanya admin yang boleh mengakses halaman ini.")
            return redirect(url_for('main.barang'))
        return f(*args, **kwargs)
    return decorated_function

@main.route('/barang')
def barang():
    # Hapus cek login
    keyword = request.args.get('keyword', '').strip()
    harga_min = request.args.get('harga_min', '')
    harga_max = request.args.get('harga_max', '')

    query = Barang.query

    if keyword:
        query = query.filter(Barang.nama.ilike(f"%{keyword}%"))
    if harga_min.isdigit():
        query = query.filter(Barang.harga >= float(harga_min))
    if harga_max.isdigit():
        query = query.filter(Barang.harga <= float(harga_max))

    daftar_barang = query.all()
    return render_template('barang.html', daftar_barang=daftar_barang)


@main.route('/tambah', methods=['GET', 'POST'])
@admin_required
def tambah():
    if request.method == 'POST':
        nama = request.form['nama']
        deskripsi = request.form['deskripsi']
        harga = float(request.form['harga'])
        stok = int(request.form['stok'])

        barang = Barang(nama=nama, deskripsi=deskripsi, harga=harga, stok=stok)
        db.session.add(barang)
        db.session.commit()
        return redirect(url_for('main.barang'))

    return render_template('tambah.html')

@main.route('/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def edit(id):
    barang = Barang.query.get_or_404(id)
    if request.method == 'POST':
        barang.nama = request.form['nama']
        barang.deskripsi = request.form['deskripsi']
        barang.harga = float(request.form['harga'])
        barang.stok = int(request.form['stok'])

        db.session.commit()
        return redirect(url_for('main.barang'))
    
    return render_template('edit.html', barang=barang)

@main.route('/hapus/<int:id>')
@admin_required
def hapus(id):
    barang = Barang.query.get_or_404(id)
    db.session.delete(barang)
    db.session.commit()
    return redirect(url_for('main.barang'))

@main.route('/about')
def about():
    return render_template('about.html')

@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        # Cek apakah username sudah ada
        if User.query.filter_by(username=username).first():
            flash('Username sudah digunakan!')
            return redirect(url_for('main.register'))

        new_user = User(username=username, password=hashed_password, role='user')
        db.session.add(new_user)
        db.session.commit()
        flash('Registrasi berhasil, silakan login.')
        return redirect(url_for('main.login'))

    # Jika GET, tampilkan form
    return render_template('register.html')


@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']

        user_login = User.query.filter_by(username=username).first()
        if user_login and check_password_hash(user_login.password, password):
            session['user_id'] = user_login.id
            session['username'] = user_login.username
            session['role'] = user_login.role
            return redirect(url_for('main.barang'))
        else:
            flash('Username atau password salah!')
            return redirect(url_for('main.login'))

    return render_template('halaman_login.html')

@main.route('/admin', methods=['GET', 'POST'])
def login_admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Hardcoded admin credentials
        if username == "irfan" and password == "12345678":
            session['user_id'] = 'admin_static'
            session['role'] = 'admin'
            flash("Login admin berhasil!")
            return redirect(url_for('main.dashboard_admin'))
        else:
            flash("Username atau password admin salah.")
            return redirect(url_for('main.login_admin'))

    return render_template('login_admin.html')

@main.route('/dashboard_admin')
@admin_required
def dashboard_admin():
    return render_template('dashboard_admin.html')




@main.route('/beli/<int:id>', methods=['GET', 'POST'])
def beli(id):
    barang = Barang.query.get_or_404(id)

    if request.method == 'POST':
        jumlah = int(request.form['jumlah'])
        nama_pembeli = request.form['nama_pembeli'].strip()

        if jumlah > barang.stok:
            flash('Jumlah melebihi stok yang tersedia!')
            return redirect(url_for('main.beli', id=id))

        total = barang.harga * jumlah

        transaksi = Transaksi(
            user_id=session.get('user_id'),  # None jika guest
            nama_pembeli=nama_pembeli,
            barang_id=barang.id,
            jumlah=jumlah,
            total_harga=total
        )

        barang.stok -= jumlah
        db.session.add(transaksi)
        db.session.commit()

        flash('Transaksi berhasil!')
        return redirect(url_for('main.struk', id=transaksi.id))

    return render_template('beli.html', barang=barang)




@main.route('/transaksi')
def transaksi():
    if 'user_id' not in session:
        return redirect(url_for('main.login'))

    transaksi_user = Transaksi.query.filter_by(user_id=session['user_id']).all()
    return render_template('transaksi.html', transaksi=transaksi_user)


from functools import wraps

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash("Hanya admin yang boleh mengakses halaman ini.")
            return redirect(url_for('main.barang'))
        return f(*args, **kwargs)
    return decorated_function

@main.route('/transaksi/guest')
def transaksi_guest():
    flash('Transaksi berhasil. Terima kasih telah membeli!')
    return render_template('transaksi_guest.html')


@main.route('/logout')
def logout():
    session.clear()
    flash('Berhasil logout.')
    return redirect(url_for('main.login'))


@main.route('/etalase')
def etalase():
    keyword = request.args.get('keyword', '').strip()
    harga_min = request.args.get('harga_min', '')
    harga_max = request.args.get('harga_max', '')

    query = Barang.query

    if keyword:
        query = query.filter(Barang.nama.ilike(f"%{keyword}%"))
    if harga_min.isdigit():
        query = query.filter(Barang.harga >= float(harga_min))
    if harga_max.isdigit():
        query = query.filter(Barang.harga <= float(harga_max))

    daftar_barang = query.all()
    return render_template('etalase.html', daftar_barang=daftar_barang)

@main.route('/struk/<int:id>')
def struk(id):
    transaksi = Transaksi.query.get_or_404(id)
    return render_template('struk.html', transaksi=transaksi)

